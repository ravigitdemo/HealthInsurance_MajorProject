$(function() {
      $( "#datepicker-1" ).datepicker();
   });
