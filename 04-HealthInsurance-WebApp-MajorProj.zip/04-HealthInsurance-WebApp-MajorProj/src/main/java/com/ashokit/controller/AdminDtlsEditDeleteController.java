package com.ashokit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.ashokit.model.AdminDtls;
import com.ashokit.service.IAdminDtlsServiceMgmt;

@Controller
public class AdminDtlsEditDeleteController {
	@Autowired
	private IAdminDtlsServiceMgmt service;
	
	@RequestMapping("/edit")
	public String handleEditBtn(@RequestParam("uid") Integer uId,Model model) {
		AdminDtls fetchRecordById = service.fetchRecordById(uId);
		model.addAttribute("adminDtls", fetchRecordById);
		return "adminRegister";
	}
	
	@RequestMapping("/delete")
	public String handleDeleteBtn(@RequestParam("uid")Integer uId) {
		boolean deleteRecordById = service.deleteRecordById(uId);
		if(deleteRecordById) {
			return "redirect:/viewRecords";
		}
		return null;
		
	}
}
