package com.ashokit.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.ashokit.model.AdminDtls;
import com.ashokit.service.IAdminDtlsServiceMgmt;

@Controller
public class AdminDtlsViewController {
	@Autowired
	private IAdminDtlsServiceMgmt service;
	
	@GetMapping("/viewRecords")
	public String viewRecords(Model model) {
		List<AdminDtls> fetchAllRecords = service.fetchAllRecords();
		model.addAttribute("msg", fetchAllRecords);
		return "successPage";
	}
	

}
