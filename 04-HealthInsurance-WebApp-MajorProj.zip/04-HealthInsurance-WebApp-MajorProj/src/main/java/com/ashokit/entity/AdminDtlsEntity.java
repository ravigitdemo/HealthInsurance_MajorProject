package com.ashokit.entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

@SuppressWarnings("serial")
@Entity
@Table(name="ADMIN_DTLS")
public class AdminDtlsEntity implements Serializable{
	@Id
	@Column(name="U_ID")
	@GeneratedValue
	private Integer userId;
	
	@Column(name="F_NAME",length=15)
	private String firstName;
	
	@Column(name="L_NAME",length=15)
	private String lastName;
	
	@Column(name="EMAIL",length=35)
	private String email;
	
	@Column(name="Phone_Number",length=11)
	private Long number;
	
	@Column(name="DOB")
	@Temporal(TemporalType.DATE)
	//@DateTimeFormat(pattern = "MM/dd/yyyy")
	private Date dob;
	
	@Column(name="GENDER",length=1)
	private String gender;
	
	@Column(name="ROLE",length=15)
	private String role;
	
	@Column(name="ACC_STATUS",length=10)
	private String acc_Status;
	
	@Column(name="TEMP_PWD",length=15)
	private String tempPwd;
	
	@Column(name="CNFRM_PWD",length=15)
	private String cnfrmPwd;
	
	@Column(name="CREATED_DATE",updatable = false)
	@CreationTimestamp
	@Temporal(TemporalType.DATE)
	private Date createdDate;
	
	@Column(name="UPDATED_DATE",insertable = false)
	@UpdateTimestamp
	@Temporal(TemporalType.DATE)
	private Date updatedDate;

	//Setter & Getter()
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getAcc_Status() {
		return acc_Status;
	}

	public void setAcc_Status(String acc_Status) {
		this.acc_Status = acc_Status;
	}

	public String getTempPwd() {
		return tempPwd;
	}

	public void setTempPwd(String tempPwd) {
		this.tempPwd = tempPwd;
	}

	public String getCnfrmPwd() {
		return cnfrmPwd;
	}

	public void setCnfrmPwd(String cnfrmPwd) {
		this.cnfrmPwd = cnfrmPwd;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	@Override
	public String toString() {
		return "AdminDtlsEntity [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + ", number=" + number + ", dob=" + dob + ", gender=" + gender + ", role=" + role
				+ ", acc_Status=" + acc_Status + ", tempPwd=" + tempPwd + ", cnfrmPwd=" + cnfrmPwd + ", createdDate="
				+ createdDate + ", updatedDate=" + updatedDate + "]";
	}
		
}
