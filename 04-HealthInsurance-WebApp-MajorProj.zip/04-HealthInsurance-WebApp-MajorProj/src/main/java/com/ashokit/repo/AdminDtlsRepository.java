package com.ashokit.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.ashokit.entity.AdminDtlsEntity;

@Repository
public interface AdminDtlsRepository extends JpaRepository<AdminDtlsEntity,Integer>{

}
