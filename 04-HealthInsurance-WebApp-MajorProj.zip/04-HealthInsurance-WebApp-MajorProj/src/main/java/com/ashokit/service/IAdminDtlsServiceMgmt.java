package com.ashokit.service;

import java.util.List;
import com.ashokit.model.AdminDtls;

public interface IAdminDtlsServiceMgmt {

	public boolean savedRecord(AdminDtls adminDtls);
	public List<AdminDtls> fetchAllRecords();
	public AdminDtls fetchRecordById(Integer uId);
	public boolean deleteRecordById(Integer uId);
}
