package com.ashokit.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ashokit.entity.AdminDtlsEntity;
import com.ashokit.generator.TempPwdGenerator;
import com.ashokit.model.AdminDtls;
import com.ashokit.repo.AdminDtlsRepository;
import com.ashokit.utils.EmailUtils;

@Service
public class AdminDtlsMgmtServiceImpl implements IAdminDtlsServiceMgmt {
	@Autowired
	private AdminDtlsRepository repo;
	
	@Autowired
	private EmailUtils emailUtils;
	
	@Override
	public boolean savedRecord(AdminDtls adminDtls) {
		AdminDtlsEntity entity=new AdminDtlsEntity();
		BeanUtils.copyProperties(adminDtls, entity);
		entity.setTempPwd(TempPwdGenerator.randomAlphaNumeric(6));
		entity.setAcc_Status("Locked");
		AdminDtlsEntity savedEntity = repo.save(entity);
		if(savedEntity.getUserId()!=null) {
			return emailUtils.sendEmailNew(adminDtls);
		}
		return false;
	}

	@Override
	public List<AdminDtls> fetchAllRecords() {
		List<AdminDtlsEntity> findAll = repo.findAll();
		List<AdminDtls> list=new ArrayList<AdminDtls>();
		findAll.forEach(e->{
			AdminDtls adminDtls=new AdminDtls();
			BeanUtils.copyProperties(e, adminDtls);
			list.add(adminDtls);
		});
		return list;
	}

	@Override
	public AdminDtls fetchRecordById(Integer uId) {
		Optional<AdminDtlsEntity> findById = repo.findById(uId);
		if(findById.isPresent()) {
			AdminDtlsEntity adminDtlsEntity = findById.get();
			AdminDtls adminDtls=new AdminDtls();
			BeanUtils.copyProperties(adminDtlsEntity, adminDtls);
			return adminDtls;
		}
		return null;
		
	}

	@Override
	public boolean deleteRecordById(Integer uId) {
		repo.deleteById(uId);
		return true;
	}
	

	
}
