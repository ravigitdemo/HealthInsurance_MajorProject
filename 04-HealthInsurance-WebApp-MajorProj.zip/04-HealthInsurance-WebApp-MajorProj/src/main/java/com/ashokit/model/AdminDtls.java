package com.ashokit.model;

import java.util.Date;

public class AdminDtls {
	private Integer userId;
	private String firstName;
	private String lastName;
	private String email;
	private Long number;
	private Date dob;
	private String gender;
	private String role;
	private String acc_Status;
	private String tempPwd;
	private String cnfrmPwd;
	
	//Setter & Getter()
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getAcc_Status() {
		return acc_Status;
	}
	public void setAcc_Status(String acc_Status) {
		this.acc_Status = acc_Status;
	}
	public String getTempPwd() {
		return tempPwd;
	}
	public void setTempPwd(String tempPwd) {
		this.tempPwd = tempPwd;
	}
	public String getCnfrmPwd() {
		return cnfrmPwd;
	}
	public void setCnfrmPwd(String cnfrmPwd) {
		this.cnfrmPwd = cnfrmPwd;
	}
	public Long getNumber() {
		return number;
	}
	public void setNumber(Long number) {
		this.number = number;
	}
	@Override
	public String toString() {
		return "AdminDtls [userId=" + userId + ", firstName=" + firstName + ", lastName=" + lastName + ", email="
				+ email + ", number=" + number + ", dob=" + dob + ", gender=" + gender + ", role=" + role
				+ ", acc_Status=" + acc_Status + ", tempPwd=" + tempPwd + ", cnfrmPwd=" + cnfrmPwd + "]";
	}
	
}
